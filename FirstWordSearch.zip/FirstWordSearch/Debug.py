###############################################################################
# Word Search (DEBUG global)
# Dr. Jean Gourd
# Last modified on 2020-11-05
#
# This makes it easier to enable or disable debug mode across all files.
###############################################################################

# debug mode?
DEBUG = True

