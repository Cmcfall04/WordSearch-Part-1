###############################################################################
# Word Search (Word.py)
# Creed McFall
# Last modified on 2023-02-02
# Professor Gourd
# This program puts all the information together from the file of words, the orientation, and the location created in the Location class and prints it out
###############################################################################

#Imports DEBUG
from Debug import DEBUG

class Word:
    #List of different orientations
    ORIENTATIONS = ["HR","HL","VD","VU","DRD","DRU","DLD","DLU"]
    #Constructor for Class Word
    def __init__(self, W, O = None, L = None):
        self._word = W
        self._orientation = O
        self._location = L
    
    #Word Getters and Setters
    @property
    def word(self):
        return self._word
    @word.setter
    def word(self, value):
        self._word = value
        
    @property
    def orientation(self):
        return self._orientation
    @orientation.setter
    def orientation(self, value):
        self._orientation = value
        
    @property
    def location(self):
        return self._location
    @location.setter
    def location(self, value):
        self._location = value
     
    #gets called  when class is called object is printed
    def __str__(self):
        #Determines if debug is true or false and returns accordingly
        if (DEBUG == True):
            return "{}/{}@{}".format(self._word.upper(), self._orientation, self._location)
        elif(DEBUG == False):
            return self._word.upper()
        