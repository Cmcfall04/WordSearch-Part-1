###############################################################################
# Word Search (Location.py)
# Creed McFall
# Last modified on 2023-02-02
# Professor Gourd
# This program creates the location for the word in teh wordsearch, and outputs the cordinates.
###############################################################################
from Debug import DEBUG
#Creates class
class Location:
    #constructor
    def __init__(self, r = 0 ,c = 0):
        self.row = r
        self.col = c
        
   #Getters and setters     
    @property
    def row(self):
        return self._row
    @row.setter
    def row(self, value):
        if (value < 0):#Range checking
            value = 0
        self._row = value
        
    #getters and setters
    @property
    def col(self):
        return self._col
    @col.setter
    def col(self, value):
        if (value < 0):# Range checking
            value = 0
        self._col = value
        
    #prints when called
    def __str__(self):
        t = "({},{})".format(self.row,self.col)
        return t#returns the cordinates